package com.example.Payee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
